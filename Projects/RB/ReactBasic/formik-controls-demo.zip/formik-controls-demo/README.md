v33: - Formik Input 
v34: - Formik TextArea 

v1: Unit TestCase: 
  Manual Testing:
     An individual will open the website , interact with website and ensure everything works as intended.
  Drawbacks:
    1.Time Consuming
    2.Complex repetitive tasks has a risk of human error
    3.You may not get a chance to test all the feature you should.

v2: 
  Jest is a javascript tesing framework
  Jest is a test runner that finds tests, runs the tests , determines whether the tests passed or failed and reports is back in a human manner.
  RTL:
    Javascript testing libraries provides a virtual DOM  for testing React components.
    React Testing library provides a virtual  DOM , which we can use to interact with and verify the behaviour of a react component.

v3:
   Three types of testing 
     Unit Testing:
         Focus is on testing the individual buliding blocks of an application as a class or functional components.
         Each unit or building block is tested in isolation , independent of other units.
     Focus Testing:
         Focus is on testing a combination of units and ensuring they work together.
         Take longer than unit tesing.
     E2E Testing:
         Focus is on testing the entire application flow and ensuring it works as designed from start to fininsh.
v7:
  test (name , f ,timeout)
   name - The first arg is the test name used to identity the test.
   f    - The function that contains the expectations to test. 
   timeout - The time for to abort the timeout.The default timeout value is 5s.

v9:
  Test Driven Development
    is a software development process where you write testcases before writing the software code.

v10: 
  Jest watch mode:
     is an option that we can pass to jest asking to watch files that have changed since the last commit and excute tests related only to those changes files.

     to excute the specific file use pattern -> get the file -> excute the file.
      <!-- test.only('Test the Greet Componenet', ()=>{
    render(<Greet name='vennila'></Greet>)
    const TextElement = screen.getByText('Hello vennila')
    expect(TextElement).toBeInTheDocument();
}) -->
       
        <!-- test.skip('Test the Greet Componenet', ()=>{
    render(<Greet name='vennila'></Greet>)
    const TextElement = screen.getByText('Hello vennila')
    expect(TextElement).toBeInTheDocument();
}) -->

v12: 
   Describe is used for to add the heading 
v13: 
   file format 
     1.Greet.test.js 
     2.Greet.spec.js
     2.--tests-- -> create a file Greet.spec.js 
        We can use it instead of describe 
        We can use xit instead of skip 
        We cn use  nit  instead of only.
v14: 
  Functinal Coverage 
  Code Coverage 
  Branch Coverage
  Line Coverage 

V15: 
  Assertions: 
     expect()
       The argument should be the value that your code produces.

v16:
 Need to test:
   Test Component renders.
   Test Component with props.
   Test Component in different states.
   Test component reacts to events.

 Not to test:
   Implementation details.
   Third Party code 
   Code that is not important from a user point of view.

V17:
   To find a single element an the page we have
     1.getBy.. , queryBy.. , findBy..
   To find multiple element on the page we have 
    1.getAllBy.. , queryAllBy.. , findAllBy..

    The suffix can be one of Role ,LabelText , PlaceHolderText , Text , DisplayValue, AltText ,Title and finally tested.
v18: 
   getBy class of queries rturn the matching node of a query ,and throw a descriptive error if no element match or if more than one match is found. 

   The suffix can be one of Role ,LabelText , PlaceHolderText , Text , Display value , Alt text , title and finally tested.

   getByRole - 


v21: 
  getByPlaceholderText  -Will search for alltheelement with the placeholder attribute and find one that matches the given text.
  

  
         









    





    





       

    









  