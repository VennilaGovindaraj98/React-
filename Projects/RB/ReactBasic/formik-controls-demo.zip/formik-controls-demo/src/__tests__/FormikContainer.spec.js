import {render ,screen , fireEvent} from '@testing-library/react'
import FormikContainer from '../components/formikContainer'
import userEvent from '@testing-library/user-event';


describe ('Formik Container',  ()=>{
    it('renders correctly', ()=>{
        render(<FormikContainer></FormikContainer>)

        // Test the heading 
        // screen.debug()
        const pageHeading = screen.getByRole('heading' ,{
            name: 'Test Form' 
        })
        // screen.debug()
        expect(pageHeading).toBeInTheDocument();

        // Test the mandattory text
        const mandatoryText = screen.getByText('Email')
        expect(mandatoryText).toBeInTheDocument("Section 1")

        // // Test the Description Label
        // const descriptionLabel = screen.getByText('Description')
        // expect(descriptionLabel).toBeInTheDocument()

        // Test the description element
        const  descriptionEle  = screen.getByRole('textbox' , {
            name: 'Description'

        })
        expect(descriptionEle).toBeInTheDocument()

        // Test the Email element 
        const EmailEle = screen.getByRole('textbox' , {
            name: 'Email'
        })
        expect(EmailEle).toBeInTheDocument()

       // Test with Email label 
        const emailLabelText = screen.getByLabelText('Email')
        expect(emailLabelText).toBeInTheDocument()

        // Test with description label 
        const descriptionLabelText = screen.getByLabelText('Description')
        expect(descriptionLabelText).toBeInTheDocument()
        // Test with placeholder text
        const emailPlaceholder  = screen.getByPlaceholderText('Enter an Email')
        expect(emailPlaceholder).toBeInTheDocument()

        // Select place 
        const placeEleText = screen.getByText(/select a place/i)
        expect(placeEleText).toBeInTheDocument()

        const placeEle = screen.getByRole('combobox', {
            name: /select a place/i 
          })
        expect(placeEle).toBeInTheDocument()

    })
    // Need to write testcase there
    // it('renders correctly', ()=>{
    //     render(<FormikContainer></FormikContainer>)

    //     const test = screen.getAllByRole('option' , {name: 'Select a country'})
    //     console.log(test , 'test')
    //     // const test = screen.getByRole('option', { name: 'Select a country' })
          
    // })


})

describe ('Test Email field',  ()=>{ 
    it('Check the text', ()=>{ 
      render(<FormikContainer></FormikContainer>)
      const EmailText =  screen.getByText(/email/i) 
      expect(EmailText).toBeInTheDocument()
    })

    it('Check the placeholder' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const emailPlaceholder  = screen.getByPlaceholderText('Enter an Email')
        expect(emailPlaceholder).toBeInTheDocument()
    })

    it ('check the text input' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const inputEl = screen.getByTestId("email-input");
        expect(inputEl).toBeInTheDocument();
        expect(inputEl).toHaveAttribute("type", "email");
    })

    it('pass vaild email to test email input field' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const inputEl = screen.getByTestId("email-input");
        userEvent.type(inputEl ,  "test@mail.com")
        expect(inputEl).toHaveValue("test@mail.com");
        expect(screen.queryByTestId("error-msg")).not.toBeInTheDocument();
    })


       test('pass the invaild email to test the input field' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const inputEl = screen.getByTestId("email-input");
        const button = screen.getByRole('button', {
            name: /submit/i
          })
        userEvent.type(inputEl ,  "test")
        expect(inputEl).toHaveValue("test");
        userEvent.click(button)
    //    expect(screen.queryByTestId("error-msg")).toBeInTheDocument();   
        // fireEvent.mouseDown(document)

        // Need to check else part 
        // fireEvent.click(button)
        // userEvent.click(document.body);
        // expect(screen.queryByTestId("error-msg")).toBeInTheDocument();
        // render(<FormikContainer></FormikContainer>)
        // const inputEl = screen.getByTestId("email-input");
        // const button = screen.getByRole('button', {
        //     name: /submit/i
        //   })
        // userEvent.type(inputEl ,  "test")
        // expect(inputEl).toHavealue("test");
        // screen.debug()
        // fireEvent.click(button)
        // screen.debug()
        // // userEvent.click(document.body);    
    })



    
})


describe ('Formik Container',  ()=>{

    it('Check the text' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const descriptionTxt = screen.getByText(/description/i)
        expect(descriptionTxt).toBeInTheDocument()
    })

     it ('Check the description input' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const inputEl = screen.getByTestId("description-input");
        expect(inputEl).toBeInTheDocument();
        expect(inputEl).toHaveAttribute("type", "description");
     })
    
     it ('Check the text' , ()=>{
        render(<FormikContainer></FormikContainer>)
        const inputEl = screen.getByTestId("description-input");
        userEvent.type(inputEl ,  "Check the description")
        fireEvent.mouseDown(document)
        expect(inputEl).toHaveValue("Check the description");
     })
})



describe ('Should correctly set the default option' , () => {
    
    it('Check the option count' , ()=>{ 
    render(<FormikContainer></FormikContainer>)
    expect(screen.getByRole('combobox', {
        name: /select a place/i
      }).length).toBe(3)
    })

     it('check the default option' , ()=>{
        render(<FormikContainer></FormikContainer>)
        expect(screen.getByRole('option', { name: 'select an option' }).selected).toBe(true)
     })

     it ('Should allow the user to change country' , ()=>{
        render(<FormikContainer></FormikContainer>)

        userEvent.selectOptions(
            screen.getByRole('combobox'), 
            screen.getByRole('option' ,  {name: 'India'})

        )
        expect(screen.getByRole('option', { name: 'India' }).selected).toBe(true)
     })
}) 

describe ('Should correctly radio option' , () => {
    
    it ('Check the radio option count' , ()=>{ 
    render(<FormikContainer></FormikContainer>)
    expect(screen.getAllByRole('radio', {}).length).toBe(3)
    })

    it ('Should allow the user to change option' , ()=>{
        render(<FormikContainer></FormikContainer>)
        expect(screen.getByText('option 1')).toBeInTheDocument();
        expect(screen.getByText('option 2')).toBeInTheDocument();

        const secondRadio = screen.getByLabelText('option 2');
        fireEvent.click(secondRadio);
        expect(secondRadio).toBeChecked();
    
        const firstRadio = screen.getByLabelText('option 1');
        fireEvent.click(firstRadio);
        expect(firstRadio).toBeChecked();
        expect(secondRadio).not.toBeChecked();
     })



}) 


describe ('Check the checkbox field' , ()=>{
    test('Render correctly' , ()=>{
        render(<FormikContainer></FormikContainer>)
        expect(screen.getByText(/check box option 1/i)).toBeInTheDocument();
        expect(screen.getByText(/check box option 2/i)).toBeInTheDocument();
        expect(screen.getByText(/check box option 3/i)).toBeInTheDocument();
    })

    test( 'Should allow the user to change option' , ()=>{
        render(<FormikContainer></FormikContainer>)
        expect(screen.getByRole('checkbox', {
            name: /check box option 1/i
          })).not.toBeChecked();
        userEvent.click(screen.getByRole('checkbox', {
            name: /check box option 1/i
          }))
        expect(screen.getByRole('checkbox', {
            name: /check box option 1/i
          })).toBeChecked()

    })
})


describe ('check the submit button' , () =>{ 

   test('Render the button', ()=>{
    render(<FormikContainer></FormikContainer>)
    expect(screen.getByRole('button', {
        name: /submit/i
      })).toBeInTheDocument()
   })

   test ('Click the button', ()=>{
    render(<FormikContainer></FormikContainer>)
    const but = screen.getByRole('button', {
        name: /submit/i
      })

     
   })
})


describe ('check the datepicker' , ()=>{
    test ('test the datepicker' , ()=>{
     render(<FormikContainer></FormikContainer>)
     expect(screen.getByText(/pick a date/i)).toBeInTheDocument();
     const pickDateEle = screen.getByRole('textbox', {
        name: /pick a date/i
      })
      userEvent.type(pickDateEle ,  '01/01/2022')
      expect(pickDateEle).toHaveValue('01/01/2022');
    })
    
})



