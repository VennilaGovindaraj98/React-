import React from "react";

function CheckBox(props) {
  return (
    <div> </div>
  )

}

export default CheckBox