import React from 'react'
import {Field , ErrorMessage} from 'formik'
import TextError from './TextErrorNew'

function Input (props){
     const {label , name , ...rest} = props
    //  console.log( props,'ehehehehhehe')
    //  console.log(TextError)
    //  console.log(props , 'eherere is the props')
    return (

        <div className="form-element " >
           <label htmlFor={name}> {label} </label>
            <Field as = 'textarea' id={name}  name={name} {...rest}> </Field>
            <ErrorMessage name= {name} component = {TextError}></ErrorMessage>
        </div>
    )

}

export default Input