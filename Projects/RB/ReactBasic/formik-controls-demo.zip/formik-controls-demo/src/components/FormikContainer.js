import React from 'react'
import {Formik , Form, yupToFormErrors } from 'formik'
import * as YUP from 'yup'
import FormikControl from './FormikControl'

function  FormikContainer () {


    const dropdownOptions = [
        {key: 'select an option' , value: ''},
        {key: 'India' , value: 'IN'},
        {key: 'Canada' , value: 'CA'}
    ]

    const radioButtonOptions = [
        {key: 'option 1' , value: 'roption1'},
        {key: 'option 2' , value: 'roption2'},
        {key: 'option 3' , value: 'roption3'}

    ]

    const CheckBoxOptions = [
        {key: 'Check box option 1' , value: 'coption1'},
        {key: 'Check box option 2' , value: 'coption2'},
        {key: 'Check box option 3' , value: 'coption3'}

    ]

    const initialValues = {email: '' , description: '' , dropdownOptions: dropdownOptions , CheckBoxOptions: [] , birthDate: null }
    const validationSchema = YUP.object({
        email: YUP.string().email('Invalid Email Format').required('Required') ,
        description: YUP.string().required('Required'),
        selectOption: YUP.string().required('Required'),
        radioOption:  YUP.string().required('Required'),
        CheckBoxOption: YUP.array().required('Required'),
        birthDate: YUP.date().required('Required').nullable()
    })
    
    const onSubmit  = (values) =>{
        console.log('Form Data' , values)
      }
      
        
    return (
        <Formik initialValues={initialValues} validationSchema ={validationSchema} onSubmit={onSubmit}
        >
             {
                (formit) => {
                    return (
   
                       
                       <Form> 
                         <h1>Test Form</h1>
                         <p>Section 1</p>
                        <FormikControl  control= 'input' type = 'email' label = 'Email' name = 'email' placeholder = 'Enter an Email'   data-testid = 'email-input'></FormikControl>
                        <FormikControl  control= 'textarea' type ='description' label='Description' name ='description'  data-testid='description-input'></FormikControl>
                        <FormikControl control='select' label='Select a place' name = 'SelectOption' options = {dropdownOptions}></FormikControl> 
                        <FormikControl control='radio' label='Select an option' name ='radioOption' options ={radioButtonOptions}></FormikControl>
                        <FormikControl control='checkbox' label='select a option' name ='checkboxOption' options ={CheckBoxOptions}></FormikControl>
                        <FormikControl control='date' label='Pick a date' name ='birthDate'/>
                        <button type ='submit'> Submit</button>
                    </Form>)
                }
             }

        </Formik>
    )

}

export default  FormikContainer