import React from 'react'

function TextErrorNew(props){
    console.log('vennila herere finally' , props)
     return (
       <div className='error'  data-testid = 'error-msg'>
         {props.children}
     </div>)

}

export default  TextErrorNew
