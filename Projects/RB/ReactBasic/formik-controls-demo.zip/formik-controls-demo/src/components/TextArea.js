import { ErrorMessage, Field } from "formik";
import React from "react";
import TextError from "./TextErrorNew";
function TextArea(props) {
    // console.log(props , 'props')
    const {label , name , ...rest} = props
    return (
        <div className="form-element">
            <label htmlFor={name}> {label}</label>
            <Field as = 'textarea' id={name}  name={name} {...rest}> </Field>
            <ErrorMessage name= {name} component = {TextError}></ErrorMessage>
        </div>
    )


}

export default TextArea