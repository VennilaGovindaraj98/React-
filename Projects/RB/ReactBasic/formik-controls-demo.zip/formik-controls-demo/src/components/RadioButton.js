import { Field , ErrorMessage } from "formik";
import React from "react";
import TextError from "./TextErrorNew";
function RadioButton (props){

    const {label , name , options ,  ...rest} = props
    // console.log('eheheheh' , options)
    return (
        <div className="form-element">
            <label> {label}</label>
            <Field name ={name} {...rest}>
                {
                    ({field})=>{
                        return  options.map(option => {
                            // console.log('tests radiaoa' , option.key , option.value)
                           return (<div key ={option.key}>
                            <input type = 'radio'  id = {option.value}  {...field}  value={option.value} checked = {field.value === option.value}></input>
                            <label htmlFor= {option.value}> {option.key}</label>
                           </div>)

                        })
                        // ({options}.map(option => {
                        //     <div> TEST</div>
                        // }))
                        // <div> Test form</div>
                        //  return options.map(option=> {
                            // <div className= {option.key}>
                            // <input type = 'radio'  id = {option.value}  {...field}  value={option.value} checked = {field.value == option.value}></input>
                            // <label htmlFor= {option.value}> {option.key}</label>
                            //  </div>
                        //  })

                    }
                }
            </Field>
            <ErrorMessage name ={name} component ={TextError}></ErrorMessage>

        </div>

    ) 

}


export default RadioButton