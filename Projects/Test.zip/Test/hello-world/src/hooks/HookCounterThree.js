import React ,{useState} from "react";
function HookCounterThree(){

    const [name , setName] = useState({first_name: '' , last_name: ''})
    // console.log(useState(0))
    return(
     <div>
        <form>
            <input type = 'text' value={name.first_name} onChange={e=> setName({...name , first_name: e.target.value})}>
                 </input>
            <input type = 'text' value={name.last_name} onChange ={e=> setName({...name , last_name: e.target.value })}>

            </input>
            <h1> Your firstname is {name.first_name}
            </h1>
            <h1> Your lastname is {name.last_name}
            </h1>
            <h2>{JSON.stringify(name)}</h2>
        </form>
        {/* <button onClick={()=> setCount(count+ 1)}> Click me {count} </button> */}
    </div>)
}
export default HookCounterThree