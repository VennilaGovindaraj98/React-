import React ,{useState} from "react";
function HookCounterTwo(){

    const [count , setCount] = useState(0)
    console.log(useState(0))
    return(
     <div>
        <button onClick={()=> setCount(count+ 1)}> Increment </button>
        <h1> counter {count}</h1>
        <button onClick={()=> setCount(prev => prev - 1  )}> Decrement</button>
        <button onClick={()=> setCount(1 - 1 )}> Reset</button>

    </div>)
}
export default HookCounterTwo