import React ,{useState , useEffect} from "react";
function HookCounterFive(){

    const [count , setCount] = useState(0)
    useEffect(()=>{
        document.title = `you have clicked ${count}`
    })
    return(
     <div>
        <button onClick={()=> setCount(count+ 1)}> Increment </button>
        <h1> counter {count}</h1>
    
    </div>)
}
export default HookCounterFive