import React ,{Component} from "react";

class ClassCounter extends Component
{
  constructor (){
    super()
    this.state = {
        count: 0 
    }

  }

  handler = ()=>{
    this.setState({
        count: this.state.count + 1
    })
    }

    render(){
        const {count} = this.state
        return (<div> <button onClick={this.handler}> click me {count} </button></div>)
    }



}

export default ClassCounter

// =>function 
// spread operator 
// array de-structring 
