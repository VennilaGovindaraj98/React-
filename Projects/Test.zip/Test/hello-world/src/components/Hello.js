import React from "react";

const Hello = () => { 
    // with JSX
    // return (<div className: 'dummyClass'><h1>Hello Vennila</h1></div>)
    // without JSX
    //  return React.createElement('div' , {} ,   'This is vennila here without JSX')  
  return React.createElement('div' , {id: 'hello' , className: 'dummyClass'} ,   React.createElement('h1' , {} ,'This is vennila here without JSX'))  
}

export default Hello