import React ,{Component}from "react";
class RefsComp extends Component
{
    constructor(){
        super()
            //  first appr
            // this.inputRef = React.createRef()
            // second  appr 
            this.cbRef = null 
            this.setCbRef = (element) => {
                this.cbRef = element
            }

    }
    componentDidMount(){
        // first app
        // this.inputRef.current.focus()
        // console.log(this.inputRef)

        // secon app
          if (this.cbRef){
            this.cbRef.focus()
          }

    }
    eventHandler = () =>{
    //  alert(this.inputRef.current.value)
    alert(this.cbRef.value)

    }
    render(){
        return (<div>
            {/* <input type="text" ref = {this.inputRef}></input> */}
            <input type="text" ref = {this.setCbRef}></input>
            <button onClick={ this.eventHandler}>Click </button>
        </div>)
    }
}

export default RefsComp