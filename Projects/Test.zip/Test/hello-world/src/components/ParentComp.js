import React ,{Component} from "react";
import RegularComp from "./RegularComp";
import PureComp from "./PureComp";
import MemoComp  from "./MemoComp";

class ParentComp extends Component {

    constructor(){
        super()
        this.state = {
            name: 'vennila'
        }
    }

    componentDidMount(){
        setInterval (()=> {
        this.setState ({
            name: 'egeh'
        })
        } , 2000)

    }
    render (){
        console.log('Parent compe')

        return (<div> Parent Component
              <MemoComp name = {this.state.name}/>
              {/* <RegularComp name = {this.state.name }/>
              <PureComp  name = {this.state.name }/> */}
        </div>)
    }
}
export default ParentComp