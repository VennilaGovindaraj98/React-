import React ,{Component} from "react";
import ComponentD from "./ComponentD";
class ComponentC extends Component
{
    render(){
        return <h1><ComponentD/></h1>
    }

}
export default ComponentC