import React from "react";
function Columns (){
    const items = [{id: '12' , title: 'test1'} , { id: 13 , title: 'title2'}]
    return (<React.Fragment>
        {items.map(item => 
        <React.Fragment key ={item.id}>
            <h2>{item.id}</h2>
            <h1> {item.title}</h1>
         </React.Fragment>   
        
        )}
        <td> Vennila</td> 
     <td>Rha</td></React.Fragment>)
}

export default Columns