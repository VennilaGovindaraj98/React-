import React ,{Component} from "react";
class UserGreeting extends Component
{

    constructor(){
        super()
        
        this.state = {
            LoggedIn: true
        }
    }
 render(){
    // let message 
    //     if (this.state.LoggedIn){
    //         message = 'Fisrt 1'     
    // }
    // else {
    //     message = 'Second 1'     
    // }
    // return (
    //     <div> {message}</div> 
    //    )
    // return (this.state.LoggedIn? <div>Firts one</div> : <div>Second one</div>)
    return (this.state.LoggedIn && <div>Second one</div>)

    
 }
}

export default UserGreeting