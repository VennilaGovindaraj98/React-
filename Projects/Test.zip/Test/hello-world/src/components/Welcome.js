import React , {Component} from "react";
 
// class Welcome extends Component {
//   render (){
//     return (
//         <div> 
//             <h1>Class Component {this.props.name} age {this.props.age}</h1>
//             <p>{this.props.children}</p>
//         </div>

//     )
//   }
// }

// de-structuring
class Welcome extends Component {
    render (){
      const {name  , age,children} = this.props
      return (
          <div> 
              <h1>Class Component {name} age {age}</h1>
              <p>{children}</p>
          </div>
  
      )
    }
  }

export default Welcome
