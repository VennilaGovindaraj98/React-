import React from "react";
const UserContext = React.createContext('codevalution')
const UserProvider = UserContext.Provider
const UserConsumer = UserContext.Consumer

export {UserProvider , UserConsumer }

export default UserContext