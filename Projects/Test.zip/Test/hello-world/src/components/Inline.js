import React from "react";

const heading = {
    fontSize: '72px',
    color: 'blue'
}
function Inline(){
    return (<div> 
    <div style={heading}>inline js</div>
    <h1 className='error'>ERROR</h1>
    </div>)
}
export default Inline 