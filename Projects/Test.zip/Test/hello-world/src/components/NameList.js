import React from "react";
import Person from "./Person";
function NameList(){
    const persons = [{id: 1 , name: 'vennila'  , age: '23'} ,{ id: 2 , name: 'pushpa' , age: 23} , { id: 3 , name: 'deeepa' , age: '23'}]
    const personsList = persons.map(person =>  <Person key = {person.id} person = {person}/>)
    return <div>{personsList}</div>
}

export default NameList