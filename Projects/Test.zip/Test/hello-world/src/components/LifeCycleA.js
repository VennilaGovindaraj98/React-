import React , {Component} from "react";
import LifeCycleB from "./LifeCycleB";
class LifeCycleA extends Component
 

{
    constructor(props) {
        super(props)
        this.state = {
            name: 'vennila'
        }
        console.log('LifecycleA constructor')
    }

    static getDerivedStateFromProbs(probs , state) {
        console.log('LifeCycleA getDerivedStateFromProbs')
        return null
    }

    // static getDerivedStateFromProbs(props , state){
    //     console.log('tete')

    // }
    componentDidMount(){
        console.log('LifeCycleA ComponentDidMount')
    }
    shouldComponentUpdate(){
        console.log('LifeCycleA shouldComponentUpdate')
        return true 
    }

    getSnapshotBeforeUpdate(){
        console.log('LifeCycleA getSnapshotBeforeUpdate')
        return null
    }

    componentDidUpdate(){
        console.log('LifeCycleA componentDidUpdate')

    }
  
    changeState = ()=> {
        this.setState ({
            name: 'code evaluvation'
        })
    }
    render(){
        console.log('LifecycleA  render')
        return(<div><div>Lifecycle A</div>
         <button onClick= {this.changeState}>Change state</button>
         <div> <LifeCycleB/></div> 
         </div>)
    }V
}

export default LifeCycleA