import React ,{Component} from "react";
class EventBlind extends Component 
{
    constructor (){
        super ()
            this.state = {
                message: 'hello'
        }
        // this.Handler = this.Handler.bind(this)
    }
    Handler(){
        this.setState({
            message: 'Goood day'
        })
        console.log(this)

        
    }
    clinkHandler =()=>{
        this.setState ({
            message: 'good dayy'
        })
    }
    render(){
        // return (<div> {this.state.message} <button onClick={() => this.Handler()}> Click me</button> </div>)
        // return (<div> {this.state.message} <button onClick={this.Handler.bind(this)}> Click me</button> </div>)
        // Best way to use this
        return (<div> {this.state.message} <button onClick={this.clinkHandler}> Click me</button> </div>)
    }
}

export default EventBlind