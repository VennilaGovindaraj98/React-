import React  from "react";
import ErrorBoundary from "./ErrorBoundary";

function Hero({heroName}){
    // return({
    //     // if (heroName ==='test') {

    //     // }  
    // }
// )
if (heroName === 'test'){
    throw new Error('Not defined')
}
return (
<div> {heroName}</div>)
}
export default Hero