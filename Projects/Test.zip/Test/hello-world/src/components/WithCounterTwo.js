import React , {Component} from "react";

class WithCounterTwo extends Component
{
    constructor(){
        super()
        this.state = {
            count: 0 
        }
    }

    getCount = () => {
     this.setState(prev =>{
       return {count: prev.count + 1}
     })
    }

    render(){
        return (<div> {this.props.render(this.state.count , this.getCount)} </div>)
    }
}

export default WithCounterTwo