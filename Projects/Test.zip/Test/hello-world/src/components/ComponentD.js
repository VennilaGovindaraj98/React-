import React ,{Component} from "react";
import ComponentE from "./ComponentE";
import UserContext from "./UserContext";
class ComponentD extends Component
{
   static contextType = UserContext
    render(){
        return (
            <div>
                <h1> hehehe {this.context} </h1>
               <h1> 
            <ComponentE/>
            </h1>
            </div>)           
    }

}
// ComponentD.contextType = UserContext
export default ComponentD