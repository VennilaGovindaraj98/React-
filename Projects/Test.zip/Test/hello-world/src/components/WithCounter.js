import React from "react";

const WithCounter = ( OriginalComponent , IncrementNumber) =>{
    class newComp extends React.Component{

        constructor(){
            super()
            this.state = {
                count: 0 
            }
        }
    
        CountClick = () => {
            this.setState(prevState =>{
                return {count: prevState.count + IncrementNumber}
            })
    
        }
        render (){
            console.log(this.props.name)
            return <OriginalComponent count = {this.state.count} countclick = {this.CountClick} {...this.props}  />
        }
    }
  return  newComp 
}

export default  WithCounter 