import React ,{Component} from "react";

class User extends Component {
    render (){
        console.log('Regular compe')

        return (<div> {this.props.name(false)}</div>)
    }
}
export default User