import React ,{Component} from "react";
import Input from "./Input";
class FocusInput extends Component
{
    constructor(){
        super()
        this.compRefs = React.createRef()
    }

    clickHandler=()=>{
      this.compRefs.current.focusInput()
    }

    render(){
        return (<div> 
            <Input ref = {this.compRefs}/>
            <button onClick = {this.clickHandler}> click me</button>
        </div>)
    }
}

export default FocusInput