import React ,{Component} from "react";
import { UserConsumer } from "./UserContext";
class ComponentE extends Component
{
    render(){
        return (
            <UserConsumer>
                {(userName) =>{
                    return (<div> Helo {userName}</div>)

                }}
            </UserConsumer>
        )
    }

}
export default ComponentE