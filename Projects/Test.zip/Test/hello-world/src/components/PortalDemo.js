import React from "react";
// import { ReactDOM } from "react";
import  ReactDOM from "react-dom";
function PortalDemo (){
    return ReactDOM.createPortal(
        <div>
       Potal Demo
    </div> , document.getElementById('portal-root')

    )
    // return React.createPortal(<div>
    //     Potal Demo
    //     </div> , document.getElementById('portal-root'))

}
export default PortalDemo