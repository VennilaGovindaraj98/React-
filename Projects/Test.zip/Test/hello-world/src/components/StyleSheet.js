import React from "react";
import './myStyles.css'
function StyleSheet(props){
    let ClassName = props.primary ? 'primary' : ''
    return <div><h1 className= {`${ClassName} font-xl`}> Style Sheet</h1> </div>
}

export default StyleSheet