import React , {Component} from "react";
 class HoverCounter extends Component {

    constructor(){
        super()
        this.state = {
            count: 0 
        }
    }

    HoevrClick = () => {
        // console.log('heheheh')
        this.setState(prevState =>{
            return {count: prevState.count + 1}
        })

    }

    render () {
        const {count } = this.state
        return(<h1 onMouseOver={this.HoevrClick}>Click me venne {count}</h1>)
    }
 }

export default HoverCounter