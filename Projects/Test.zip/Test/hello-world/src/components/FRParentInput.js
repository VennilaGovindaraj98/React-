import React , {Component} from "react";
import FRInput from "./FRInput";
class FRparentInput extends Component
{
    constructor(){
        super()
        this.inputRef = React.createRef()
    }

    handler = ()=>{

        this.inputRef.current.focus()

    }

    render(){
        return (
           <div> 
            <FRInput ref = {this.inputRef}/>
            <button onClick = {this.handler}> fOCUS</button> 
             </div>)
    }
}

export default FRparentInput