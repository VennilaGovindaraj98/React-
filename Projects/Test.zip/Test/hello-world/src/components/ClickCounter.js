import React , {Component} from "react";
import WithCounter from "./WithCounter";
 class ClickCounter extends Component {

   

    render () {
        console.log(this.props)
        const {count , countclick} = this.props
        
        return(<div> <button onClick={countclick}> {this.props.name} Click me {count}</button></div>)
    }
 }

export default WithCounter(ClickCounter , 2)