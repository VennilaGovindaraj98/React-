import React ,{Component} from "react";

class Form extends Component
{
    constructor(props){
        super(props)
        this.state = {
            name: 'vennila',
            comment: 'vennila',
            topic: 'ror'
        }
    }
    handleUserNameChange = (event ) => {
        this.setState({
            name:  event.target.value
        })
    }

    handleCommentChange = (event) => {
        this.setState({
          comment: event.target.value  
        })
    }
    handleTopicChange = (event)=>{
       this.setState({
        topic: event.target.value
       })
    }

    handleSubmit = (event)=>{
       alert(`${this.state.name} ${this.state.comment} ${this.state.topic}`)
       event.preventDefault()
    }
    render(){
        return(<form onSubmit={this.handleSubmit}> 
            <div> 
             <label> Username</label>
             <input type='text'  value= {this.state.name} onChange = {this.handleUserNameChange}/>
             
            </div>
            <div>
                <label> Comments</label>
                <textarea type = 'text' value = {this.state.comment} onChange = {this.handleCommentChange}></textarea>
            </div>
            <div>
                <label> Select Topics</label>
                <select value = {this.state.topic} onChange = {this.handleTopicChange}>
                <option value = 'react'>React</option>
                 <option value = 'angular'>Angular</option>
                 <option value = 'ror'>Ruby On Rails</option>
                </select>
            </div>
            <button type ='submit'> Submit</button>
        </form>)
    }
}

export default Form
