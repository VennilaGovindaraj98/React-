import React ,{Component} from "react";
class ClickCounterTwo extends Component {
    

    render(){
        const {count ,getCount} = this.props
        console.log(this.props)
        return (<button onClick = {getCount}> clicked {count} times</button>)
    }
}

export default ClickCounterTwo