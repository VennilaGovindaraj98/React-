import React  from "react";


function FuctionClick(){
    function ClickHandler() {
        console.log('whwh')
    
    } 
    return (<div> <button onClick={ClickHandler}> Click</button></div>)
}

export default FuctionClick