import React from 'react'
// function Greet(){
//     return <h1> This is Vennila G</h1>
// }

// arrow function with ES6

// const Greet = (props) => {
// console.log(props)
// return (
// <div>
// <h1> This is {props.name} age {props.age}</h1>
// {props.children}
// </div>
// )
// }

// Destring 

// const Greet = ({name , age , children}) => {
//     // console.log(props)
//     return (
//     <div>
//     <h1> This is {name} age {age}</h1>
//     {children}
//     </div>
//     )
//     }

const Greet = props => {
    const {name , age , children} = props
    return (
            <div>
            <h1> This is {name} age {age}</h1>
            {children}
            </div>
            )   
}
export default Greet

// two ways of export options 
//    1. const Greet = () => <h1> This is Vennila Gonvindaraj</h1>
//    export default Greet
//    import  Greet from './components/Greet';

//    2. export const Greet = () => <h1> This is Vennila Gonvindaraj</h1>
//   import {Greet} from './components/Greet';
