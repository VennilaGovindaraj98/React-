import React , {Component} from "react";
class LifeCycleB extends Component
 

{
    constructor(props) {
        super(props)
        this.state = {
            name: 'vennila'
        }
        console.log('LifecycleB constructor')
    }

    static getDerivedStateFromProbs(probs , state) {
        console.log('LifeCycleB getDerivedStateFromProbs')
        return null
    }

    // static getDerivedStateFromProbs(props , state){
    //     console.log('tete')

    // }
    componentDidMount(){
        console.log('LifeCycleB ComponentDidMount')
    }

    shouldComponentUpdate(){
        console.log('LifeCycleB shouldComponentUpdate')
        return true 
    }

    getSnapshotBeforeUpdate(){
        console.log('LifeCycleB getSnapshotBeforeUpdate')
        return null 
    }

    componentDidUpdate(){
        console.log('LifeCycleB componentDidUpdate')

    }

    
    render(){
        console.log('LifecycleB  render')
        return(<div>Lifecycle B</div>)
    }
}

export default LifeCycleB