import React , {useState , useEffect}from "react";
function AutoIncreCounter()
{
    const [counter,  setCounter ] = useState(0)
    
    useEffect (()=> {
        const interval = setInterval(()=>{
            // console.log('Setcounter func')
            setCounter(prev => prev + 1  )
        } , 1000)
        return ()=>{
            // console.log('Clear interval')
            clearInterval(interval)
        }
    }, [counter])

    return (
    <div class="wrapper">
    <div class="counter">
    <h1> {`Counter  ${counter}`} </h1>
    </div>
    </div>
    )

}
export default AutoIncreCounter