# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)


Functional Component: 
   Functional components are just JavaScript function. They are optionally receiving an object of properties which is referred to props a return HTML which describes the UI.
    Example:  Greet.js

Class Component: 
   Class Components are basically es6 classes similar to a functional component a class component also can optionally receive props as input and return HTML.A class component can also maintain a private internal state to the component and use that info to describe the UI. 
     Example:  Welcome.js

Hooks Update:  

JSX: 
   Exmaple: Hello.js 

Props:
   Functional componenent:  props.name  , props.children - Greet.js
   Class Componenent:   this.props.name  , this.props.children - Welcome.js


 Props                                                               State: 

 

 1.props get passed to the component                   state is managed withing the component 

 2.Function parameters                                  Variable declared in the function body  

3.Props are immutable                                   State can be chanaged. 

4.Props - Functional com                                usestate Hook – func  

This.props - class com                               this.state - class component 
         
    Greet.js                                             Message.js , Counter.js
    welcome.js                         

SetState: 

      Always make use of setstate and never modify the state directly.  

     Code has to be executed after the state has been updated ?  Place that code in the call back fun which is the second arg to the setState method. 

      When you have to update state based on the previous state value , pass in a fun as an argument instead of regular object. 

     Example: 

           Message.js  

           Counter.js  

Event Handling JS: 

    Example :   FuctionClick.js  , ClassClick.js 

Binding Event Handling: 
    Example:  EventClick.js 

Method as props : 
    ParentComponenet.js , ChildComponent.js 

Conditional Rendering: 
    UserGreeting.js  

Styling React Component: 
    1.CSS styleSheet. 
    2.Inline styling 
    3.CSS Modules 
    4.CSS in JS Libaries    

    Example:  StyleSheet.js , Inline.js , myStyles.css , appStyles.css , appStyles.module.css 

Basic of Form Handling: 
    Example: Form.js

LifeCycle Methods:

     It works only in class component.
     Mounting  :    When an instance of component is being created and inserted into the DOM.

                     constrctor ,static getDrivedStateFromProbs , render and componentDidMount.

     Updating  :  When the component is beging re-rendenred as a result of changes to either its props or state.
                     Static getDerivedStateFrompROBS , shouldComponentUpdate , rendergetSnapShotBeforeUpdate and componentUpdate.

     UnMounting:  When a componenet being removed from the DOM.

                     componenetWillUnmount  

     Error Handling:  When the error during rendreing , in a lifecycle method , or in the constructor of any child component.
       
                      static getDrivedStateFromError and componentDidCatch


                         
Mounting: 
constructor(props)  
     A special fun that will get called whenever a new component is created.
     Intialize the state
     Binding the event handlers.
     Directly overwirte this.state
     Do not cause any side effects - hhtp request. 

Stactic getDrivedStateFromProps:
    when the state of the component depends on changes in props over time.
    set the state.
    Do not cause any side effects - hhtp request. 

 Render()
    Only requried method. 
    Read props and state and return JSX.
    Do not change state or interact with DOM or Make ajax calls.
    Child component lifecycle methods are also excuted.

 ComponentDidMount:
     Invoke immediately after a componenet and all its children components have been rendered ti the Dom
     cause side effect ex: interact with DOM and ajax call

     Example: LifeCycleA , LifeCycleB
Updating LifeCycle Methods: 
Static getDrivedStateFromProps(probs , state) 
     Dictates if the component should re-render or not. 
   ShouldCompnenetUpdate(nextProps , nextState) 
    performance optimization 
    Do not cause side effects 
    Calling the setState Method

Render: 
    Only requried method. 
    Read props and state and return JSX.
    Do not change state or interact with DOM or Make ajax calls.
    Child component lifecycle methods are also excuted.

getSnapShotBeforeUpdate(prevProbs , prevState) 
    
    Called right before the changes from the virtual DOM are to reflected in the DOM.
    Capture some informetion from the DOM.
    Method will either return null or return a value.Retured value will be passed as the third params to the next method.

componentDidUpdate(prevProbs , prevstate , snapshot) 
      Called after the render is finished in the re-render cycles 
      Cause side effects.
      Example: LifeCycleA , LifeCycleB

Unmounting:
  ComponentWillUnmount:
   Method is invoked immediately before a component is unmounted and destroyed.
   Cancelling any network requests , removing event handlers , cancelling any subsciption and also invalidating timers.
   Do not call the setState method. 

Error handling:
    static getDerivedFromError(error) 
    componentDidCatch(error , info)
     When there is an error either during rendering in a lifecycle method 
    In the constructor of any child component.

Fragments: 
   Fragments basically lets you group a list of children elements without adding extra nodes to the dom.
    EX:  Table , Column , FragmentDemo 

Pure Component: 
  We can create a component by extenting the PureComponent class. 
  A pureComponent implements the shouldComponetUpdateMethodUpdate LifeCycle method by performing a shallow comparision on the props and state of the component. 
  if there is no diff , the comp is not re-rendered.
  Example: ParentComp , RegularComp , PureComp

Memo:  

  It will work as pureComponet but it for functional component.
  if there is no diff , the com is not re-rendered.
  Example: MemoComp , ParentComp

Refs:
  Make it possible to acccess the dom node directly within react.
  example: RefsComp.js

Refs with class Component: 
  Example: Input , FocusInput 

Forwarding Refs:
 Example: FRIpuput , FRParentInput 

Portals:
  we can use the diffrent dom root.
   INDEX.HTML , portalDemo.js

Error: 
  ErrorBondary , Hero - Not working corrently 

Higher order component: [code optimization]
  Example: click count  - Clickcounter , HoverCouner
   A pattern where a function takes a component as an arg and return a new component.
   Example: withCounter , clickCounter 

render props: 
   User.js , CounterClickTwo , withCounterTwo

Context:
    Context provide a way to pass the data through the component tree without having to pass props down manually at every level.

 UseState: [Hook]
    You can access the previous state value in functinal component.
    Example:  HoodCounterTwo.js 
    





      
  

     
  


    


     
    
 
  
   

   

          
  
      




        




     




          





      

        






