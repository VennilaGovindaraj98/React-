import { BUY_CAKE } from "./cakeType"
console.log('actions')
export const buyCake = () =>{
  return {
    type: BUY_CAKE
  }
}