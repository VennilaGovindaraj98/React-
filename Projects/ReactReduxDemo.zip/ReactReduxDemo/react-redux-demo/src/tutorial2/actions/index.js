const INCREMENT = 'INCREMENT'
const DECREMENT ='DECREMENT'

export const increment = (()=>{
    return {
        type: INCREMENT
    }   

})

export const decrement = (()=>{
    return {
        type: DECREMENT
    }   

})


export const isloogedin = (()=>{
    return {
        type: SIGN_IN
    }   

})
