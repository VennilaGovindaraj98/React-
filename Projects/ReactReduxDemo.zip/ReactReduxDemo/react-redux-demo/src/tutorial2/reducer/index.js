import isLoggedIn from "./isLoggedIn";
import counter from "./counter";
import { combineReducers } from "redux";
const store = combineReducers({isLoggedIn: isLoggedIn ,counter: counter })
 
export default store;

// export combineReducers(isLoggedIn , counter)