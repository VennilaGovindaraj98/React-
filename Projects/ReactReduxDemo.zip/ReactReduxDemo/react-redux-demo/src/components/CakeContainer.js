import React from "react";
import { buyCake } from "../redux";
// import { buyCake } from "../redux/cakes/cakeActions";
import {connect} from 'react-redux'
console.log('contaier')
function CakeContainer(props){
    console.group(props , 'prpsosos hehehe')
    return (<div>
        <h2>Number of cakes {props.numberOfCake}</h2>
        <button onClick={props.buyCake}>Buy cake</button>
          </div>
    )
}

const mapStateToProps = (state) => { 
    return {
        numberOfCake: state.numberOfCake
    }
}

const mapDispactchToProps = (dispatch) => { 
    return {
        buyCake: ()=>{dispatch(buyCake())}
    }
}
 

export default connect( mapStateToProps , mapDispactchToProps)(CakeContainer)