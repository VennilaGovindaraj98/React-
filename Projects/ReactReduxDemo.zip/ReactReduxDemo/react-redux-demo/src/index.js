import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// turorial2 tutorial 
// store store - It a Globalist state
import {createStore}  from 'redux'
// action  - the fuction returns an object called action 
// Action - Decribe what you want to do. 
const INCREMENT = 'INCREMENT'
const increment =()=>{
  return {
    type: INCREMENT
  }
}

const DECREMENT = 'DECREMENT'
const decrement =()=>{
  return {
    type: DECREMENT
  }
}

// reducer 
const counter = (state = 0 , action )=>{
  switch(action) {
    case INCREMENT:
      return state + 1
    case DECREMENT:
      return state - 1
    default:
      return state 
  }
}

const store = createStore(counter) 

// display the value in console
store.subscribe(()=>{store.getState()})


// dispatch 
store.dispatch(increment())





const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
