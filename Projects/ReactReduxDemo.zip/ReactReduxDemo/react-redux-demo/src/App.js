import React from 'react';
// import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';
import CakeContainer from './components/CakeContainer';
import {Provider} from 'react-redux'
// import store from './redux/store';



// T
import {createStore }  from 'redux'
import allReducer from './Tamil/reducer'
const store = createStore(allReducer)



// const increment = () => {
//   return {
//     type: 
//   }
// }

function App() {
  return (
    <Provider store = {store}>
      <div className="App">
      {/* <CakeContainer/> */}
   </div>
  </Provider>
  );
}

export default App;
