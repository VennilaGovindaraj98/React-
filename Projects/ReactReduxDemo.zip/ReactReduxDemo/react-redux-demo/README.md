# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)


1.npm install redux react-redux
   redux - state management 
   react-redux - To combine the react and redux

Redux: 
  it is an external library used for state management.
    store = Is a only one store.
    We can use many reducer.

    store - It a Globalist state
    Action - Decribe what you want to do. 
    Reducer -  It basically describe how your action transformed the action to next state.
    Dispatch - This is where we actually execute the action.


    
ReactRedux: 
   Redux is a predictable state container for Javascript apps.
   it is for javascript apps.
   It is a state container. 
   it is predictable.
   
   1.Redux is for javascript applications and this is really important React is not tied to react it can be used with any UI library or react , angular , view or even with vannila javacript. 
   2.Redux stores the state of your application.State of an app is the state represented by all the individual component of thet app. Redux will store and manage the application state.
   3.EX: todo list app -> item(pending) -> item(completed) , in redux all atate transitions are explicit 
   to keep track of them in other words The changes to your application's state become predicitable.

   Redux is  a libary used to build UI.
   Redux is a library for managing state in a predictable way in Javascript applications.
   React-Redux is a library that provides binding to use React and Redux together in an applications.

Steps: 
    Create a new folder 
    npm init --y 
    create index.js file
    node index   

Three core Components: 
      cake shop 

  Entities 
    shop  = stores cakes on a shelf.
    shopKeeper - At the front of the store.
    customer - At the store entrance 

  Activities:
    customer - Buy a cake 
    ShopKeeper - Remove a cake from thebshelf 
                Receipt to keep track.

  Three core concepts: 
      1.state  -Holds the state of your app
      2.Action - Decribes what happend.
      3.Reducer  - Ties the store and actions together.

    First Priciple:
        The state of your whole app is stored in an object tree within a single store.
          Maintain our app state in single obj which would be managed by the Redux store.

          cake shop - le's assume we are tracing the cakee on the shelf.
             {
                numberofCakes: 10 
             }
    Second Principle: 
        The only way to change the state is to emit an action , an object describing what happend.
           To update the state of your app , you need to let redux know about that with an action.
            Not allowed to directly update the state object.
        cake shop:    
             Let the shopKeeper know about the our action - BUY CAKE. 
             {
                type: 'BUY_CAKE'
              }     
    Thrid principle:
         To specify how the state tree is transformed by actions , you write pure reducers.
         Reducer = (prev , action) -> NewState
         Cake Shop:
           Reducer is the shopKeeper.

     
    Action: 
     An action is a object with type property
     Action creator is a fun that return an action.  

    State: 
        Function that accepts the state and action as arguments and returs the next state of the app.

    Responsibilities: 
          Holds app state 
          Allow access to state via getState()
          Allow state to be updated via dispatch(action)
          Register listerners via subscribe(listerber)
          Handles unregistering of listeners via the fuc returned by subscibe(listener)
    MiddleWare: 
         Is the suggested way to extends Redux with custom functinality. 
         Privides a third party extension point between dispatching an action and the moment it reaches to reducer   
         Use middleware for logging, crash reporting , performing asychronous tasks etc....
           import applaymidleware 
           pass is an arg to create store
           pass in then middle to the apply middleware

    Asyn actions:

       Asyn API calls to fetch data from an end point and use that data in your app.
       state  ={
        loading: true , 
        data = [],
        error: ''
       }
       Action: 
         FETCH_USERS_REQUEST: Fetch list of users
         FETCH_USERS_SUCCESS: Fetched successfully.
         FETCH_USERS_FAILURE: Error fetching the data.

       Reducers: 
        FETCH_USERS_REQUEST: 
               loading: true
        FETCH_USERS_SUCCESS: 
               loading: false
               users: data {from: API} 
        FETCH_USERS_FAILURE: Error fetching the data.
               loading: true 
               error: error {from API}
               

          

I learned below topics today:
    Redux  - Action , reducer , store ,Dispatch , ComibineReducers [Tried some example and exxuted.] , middleware[redux-logger] 








               








      




